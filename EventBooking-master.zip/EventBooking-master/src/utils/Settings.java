package utils;

public final class Settings {

	// main window
	public final static Double MAIN_WINDOW_WIDTH = 720.;
	public final static Double MAIN_WINDOW_HEIGHT = 480.;
	// create new event window
	public final static Double EVENT_FORM_WIDTH = 450.;
	public final static Double EVENT_FORM_HEIGHT = 450.;
}
